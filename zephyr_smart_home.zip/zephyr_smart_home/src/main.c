#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include "../inc/lcd_screen_i2c.h"
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/rtio/rtio.h>

#define LED_YELLOW_NODE DT_ALIAS(led_yellow)
const struct gpio_dt_spec led_yellow_gpio = GPIO_DT_SPEC_GET_OR(LED_YELLOW_NODE, gpios, {0});

const struct i2c_dt_spec lcd_screen = I2C_DT_SPEC_GET(DT_ALIAS(lcd_screen));

const struct device *const dth11 = DEVICE_DT_GET_ONE(aosong_dht);

int main(void) {
    
    gpio_pin_configure_dt(&led_yellow_gpio, GPIO_OUTPUT_HIGH);
    //printk("Hello world !");

      // Init device
    init_lcd(&lcd_screen);

    // Display a message
   // write_lcd(&lcd_screen, HELLO_MSG, LCD_LINE_1);
    //write_lcd_clear(&lcd_screen, ZEPHYR_MSG LCD_LINE_2);
     
      while (1) {
        struct sensor_value temp, humidity;

		    sensor_sample_fetch(dth11);
		    sensor_channel_get(dth11, SENSOR_CHAN_AMBIENT_TEMP, &temp);
		    sensor_channel_get(dth11, SENSOR_CHAN_HUMIDITY, &humidity);

		    printk("temp: %d.%06d; humidity: %d.%06d\n",temp.val1, temp.val2, humidity.val1, humidity.val2);
		    k_sleep(K_MSEC(1000));

	}
    return 0;
}
